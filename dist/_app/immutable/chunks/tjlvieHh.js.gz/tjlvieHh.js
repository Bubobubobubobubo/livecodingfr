import{S as r,i as o,f as l,n as a,j as u,q as c,D as d,R as p,F as m}from"./CsX1GTQk.js";import"./IHki7fMi.js";function f(s){let e,n=`Cette section sert pour héberger des articles généralistes en lien avec le <em>live
coding</em>. Il peut s’agir du compte-rendu d’un évènement, d’un article à propos
d’un nouveau logiciel, d’une réflexion sur un sujet, etc. La méthode à suivre
pour publier un article est détaillée dans la section <a href="/guides">Guides</a>. Le
fonctionnement est similaire.`;return{c(){e=m("p"),e.innerHTML=n},l(t){e=d(t,"P",{"data-svelte-h":!0}),p(e)!=="svelte-1ewuhfv"&&(e.innerHTML=n)},m(t,i){c(t,e,i)},p:a,i:a,o:a,d(t){t&&u(e)}}}const h={title:"À propos des articles",author:"Raphaël Maurice Forment",date:"2024-01-01"},{title:_,author:x,date:L}=h;class C extends r{constructor(e){super(),o(this,e,null,f,l,{})}}export{C as default,h as metadata};
