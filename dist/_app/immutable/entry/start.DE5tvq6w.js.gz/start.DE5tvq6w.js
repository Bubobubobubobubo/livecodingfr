import{Z as o,Y as r}from"../chunks/CA-i7br4.js";export{o as load_css,r as start};
