import{Z as o,Y as r}from"../chunks/mlCbNT1G.js";export{o as load_css,r as start};
