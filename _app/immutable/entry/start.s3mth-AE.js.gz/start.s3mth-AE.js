import{Z as o,Y as r}from"../chunks/M-mQO4vi.js";export{o as load_css,r as start};
