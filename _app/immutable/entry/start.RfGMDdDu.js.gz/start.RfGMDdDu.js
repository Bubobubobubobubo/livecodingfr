import{Z as o,Y as r}from"../chunks/D8iAFrPf.js";export{o as load_css,r as start};
