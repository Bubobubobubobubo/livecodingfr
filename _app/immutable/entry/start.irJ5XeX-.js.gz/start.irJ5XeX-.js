import{Z as o,Y as r}from"../chunks/DL02xL7U.js";export{o as load_css,r as start};
