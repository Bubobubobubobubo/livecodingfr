const e=o=>{for(let t=o.length-1;t>0;t--){const s=Math.floor(Math.random()*(t+1));[o[t],o[s]]=[o[s],o[t]]}};export{e as s};
