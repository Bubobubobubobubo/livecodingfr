import{s as i,n as a}from"./scheduler.aZRR5A_O.js";import{S as o,i as l,g as u,h as c,x as d,a as p,f as m}from"./index.kYoizZ4A.js";function f(s){let e,n=`Cette section sert pour héberger des articles généralistes en lien avec le <em>live
coding</em>. Il peut s’agir du compte-rendu d’un évènement, d’un article à propos
d’un nouveau logiciel, d’une réflexion sur un sujet, etc. La méthode à suivre
pour publier un article est détaillée dans la section <a href="/guides">Guides</a>. Le
fonctionnement est similaire.`;return{c(){e=u("p"),e.innerHTML=n},l(t){e=c(t,"P",{"data-svelte-h":!0}),d(e)!=="svelte-1ewuhfv"&&(e.innerHTML=n)},m(t,r){p(t,e,r)},p:a,i:a,o:a,d(t){t&&m(e)}}}const g={title:"À propos des articles",author:"Raphaël Maurice Forment",date:"2024-01-01"};class _ extends o{constructor(e){super(),l(this,e,null,f,i,{})}}export{_ as default,g as metadata};
